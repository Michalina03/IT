from characters.mage import Mage
from characters.goblin import Goglin
import os
# =======================================================================

def one_on_one_fight(hero:Mage):
    opponent = Goglin()
    opponent.regeneration()
    hero.regeneration()
    while hero.is_alive() and opponent.is_alive():
        hero.reduce_hp(opponent.faight())
        opponent.reduce_hp(hero.faight())
    if not(hero.is_alive()):
        print("you gave your all today !!!")
        return None
    hero.add_gold(opponent.drop())


def main_game():
    print("Select a Character Class")
    print("a - magician")

    inp = input().lower()
    my_hero = Mage()

    while my_hero.is_alive():
        day = 1
        os.system('clear')
        print(f"======================DAY: {day}============================")
        print("a - go to the dark forest")
        print("r - rest")
        print("e - exsit")
        my_hero.inf()
        print("=="*20)

        inp = input().lower()
        if "a" == inp:
            one_on_one_fight(my_hero)
        elif "r" == inp:
            my_hero.total_rest()
        elif "e" == inp:
            print("the program has ended")
        else:
            print("there is no such command")


# =======================================================================

    
if __name__ == '__main__':
    main_game()
    
print("Thank you for playing !!!")

    

